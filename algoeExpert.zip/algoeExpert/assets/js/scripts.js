const carousel = document.querySelector('.carousel');
const items = document.querySelectorAll('.carousel-item');
const prevButton = document.getElementById('prev');
const nextButton = document.getElementById('next');

let index = 0;

function showItem(index) {
    const itemWidth = items[0].clientWidth;
    const offset = index * itemWidth;
    carousel.style.transform = `translateX(-${offset}px)`;
}

prevButton.addEventListener('click', () => {
    index = (index > 0) ? index - 1 : items.length - 1;
    showItem(index);
});

nextButton.addEventListener('click', () => {
    index = (index < items.length - 1) ? index + 1 : 0;
    showItem(index);
});
